OVICORE MOBILE SANDBOX MVP

WHAT THIS PACKAGE ADDS
- /mobile installable PWA route
- Existing OviCore session login; no credentials stored
- Existing /api/broilers/demand-plans and /api/broilers/performance endpoints
- Offline IndexedDB queue
- Automatic sync when reception returns
- Home dashboard and manager exception view for Cornelius
- Daily broiler house-sheet entry
- Home / Daily Entry / Insights / More bottom navigation

INSTALL IN NOTEPAD++
1. Extract this zip.
2. Copy each file into the matching path under:
   C:\Projects\OviCore_Next.js
3. Add your approved OviCore PNG icon files:
   public\ovicore-icon-192.png
   public\ovicore-icon-512.png
4. Open Command Prompt in C:\Projects\OviCore_Next.js
5. Run:
   npm run build
6. Fix any project-specific import alias issue only if your @ alias is not already configured.
7. Commit and deploy to sandbox.ovicore.com.au.
8. Log into sandbox, select Surfcoast Eggs as the working company, then open:
   https://sandbox.ovicore.com.au/mobile

IMPORTANT BACKEND EXPECTATIONS
The package intentionally reuses the current API contract:
- GET /api/broilers/demand-plans?company_id=...
- GET /api/broilers/performance?company_id=...
- GET /api/broilers/performance?company_id=...&placement_plan_id=...
- POST /api/broilers/performance
- PATCH /api/broilers/performance/{id}
- POST /api/auth/logout

The FastAPI server must:
- derive/validate company access from the logged-in session
- restrict ordinary users to assigned farms
- allow credentials cookies through the Next.js proxy/deployment setup

FIRST SANDBOX TEST
1. Login in desktop browser and select Surfcoast Eggs.
2. Open /mobile and select a cycle.
3. Enter today's opening birds, mortality, culls, feed and water.
4. Save online.
5. Confirm the same row appears in /broilers/performance.
6. Turn phone flight mode on, save another entry, close/reopen the PWA.
7. Restore signal and confirm the pending count returns to zero.
8. Confirm the new row appears in the desktop house sheet.

NOTE
This is a working MVP against the API structure found in the supplied OviCore files. It does not add database conflict-version fields yet; it checks for an existing placement-plan/date row before POST/PATCH to avoid duplicate daily records.
