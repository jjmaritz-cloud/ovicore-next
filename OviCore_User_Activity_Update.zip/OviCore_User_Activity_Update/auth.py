import os
from datetime import datetime
from typing import Optional

from fastapi import (
    APIRouter,
    Cookie,
    Depends,
    HTTPException,
    Response,
    status,
)
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app import models, schemas
from app.db import get_db
from app.security import (
    ACCESS_TOKEN_EXPIRE_MINUTES,
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)


router = APIRouter(
    prefix="/api/auth",
    tags=["Authentication"],
)

COOKIE_NAME = "ovicore_access_token"

COOKIE_SECURE = (
    os.getenv("COOKIE_SECURE", "true")
    .strip()
    .lower()
    == "true"
)

COOKIE_SAMESITE = (
    os.getenv("COOKIE_SAMESITE", "none")
    .strip()
    .lower()
)

EMERGENCY_ADMIN_EMAIL = (
    os.getenv("EMERGENCY_ADMIN_EMAIL", "")
    .strip()
    .lower()
)

EMERGENCY_ADMIN_PASSWORD = os.getenv(
    "EMERGENCY_ADMIN_PASSWORD",
    "",
).strip()

EMERGENCY_ADMIN_NAME = os.getenv(
    "EMERGENCY_ADMIN_NAME",
    "OviCore Administrator",
).strip()


class LoginRequest(BaseModel):
    email: str
    password: str

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

class LoginResponse(BaseModel):
    message: str
    must_change_password: bool


class CurrentUserResponse(BaseModel):
    id: int
    company_id: Optional[int] = None
    company_name: Optional[str] = None

    full_name: str
    email: str

    is_global_admin: bool
    is_company_admin: bool
    active: bool
    must_change_password: bool

    enable_broilers: bool = False
    enable_breeders: bool = False
    enable_layers: bool = False
    enable_hatchery: bool = False
    enable_processing: bool = False

    farm_ids: list[int]


def get_current_user(
    access_token: Optional[str] = Cookie(
        default=None,
        alias=COOKIE_NAME,
    ),
    db: Session = Depends(get_db),
) -> models.AppUser:
    if not access_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )

    subject = decode_access_token(access_token)

    if not subject:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired login session",
        )

    try:
        user_id = int(subject)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid login session",
        )

    user = (
        db.query(models.AppUser)
        .filter(
            models.AppUser.id == user_id,
            models.AppUser.active == True,
        )
        .first()
    )

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    return user


def get_or_create_emergency_admin(
    db: Session,
    email: str,
    password: str,
) -> models.AppUser:
    user = (
        db.query(models.AppUser)
        .filter(models.AppUser.email == email)
        .first()
    )

    if user is None:
        user = models.AppUser(
            full_name=EMERGENCY_ADMIN_NAME,
            email=email,
            password_hash=hash_password(password),
            active=True,
            is_global_admin=True,
            is_company_admin=True,
            must_change_password=False,
        )

        db.add(user)
        db.commit()
        db.refresh(user)

    else:
        user.active = True
        user.is_global_admin = True
        user.is_company_admin = True
        user.must_change_password = False

        # Keep the database password hash aligned with the
        # emergency-admin password used for login.
        user.password_hash = hash_password(password)
        user.password_changed_at = datetime.utcnow()

        db.commit()
        db.refresh(user)

    return user


@router.post(
    "/login",
    response_model=LoginResponse,
)
def login(
    payload: LoginRequest,
    response: Response,
    db: Session = Depends(get_db),
):
    normalised_email = payload.email.strip().lower()
    supplied_password = payload.password

    emergency_login_matches = (
        bool(EMERGENCY_ADMIN_EMAIL)
        and bool(EMERGENCY_ADMIN_PASSWORD)
        and normalised_email == EMERGENCY_ADMIN_EMAIL
        and supplied_password == EMERGENCY_ADMIN_PASSWORD
    )

    if emergency_login_matches:
        user = get_or_create_emergency_admin(
            db=db,
            email=EMERGENCY_ADMIN_EMAIL,
            password=EMERGENCY_ADMIN_PASSWORD,
        )

    else:
        user = (
            db.query(models.AppUser)
            .filter(models.AppUser.email == normalised_email)
            .first()
        )

        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email address or password",
            )

        if not user.active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="This user account is inactive",
            )

        if not user.password_hash:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    "This account does not have a password yet. "
                    "Please ask an administrator to reset it."
                ),
            )

        if not verify_password(
            supplied_password,
            user.password_hash,
        ):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email address or password",
            )

    token = create_access_token(
        subject=str(user.id),
    )

    response.set_cookie(
        key=COOKIE_NAME,
        value=token,
        httponly=True,
        secure=COOKIE_SECURE,
        samesite=COOKIE_SAMESITE,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        path="/",
    )

    now = datetime.utcnow()
    user.last_login_at = now
    user.last_active_at = now
    user.last_module = "auth"
    user.last_page = "/login"

    db.add(
        models.UserActivity(
            user_id=user.id,
            company_id=user.company_id,
            event_type="login",
            module="auth",
            page="/login",
            created_at=now,
        )
    )
    db.commit()

    return LoginResponse(
        message="Login successful",
        must_change_password=user.must_change_password,
    )


@router.post("/activity")
def record_activity(
    payload: schemas.UserActivityPing,
    current_user: models.AppUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    now = datetime.utcnow()
    page = (payload.page or "").strip()[:255] or None
    module = (payload.module or "").strip().lower()[:80] or None
    event_type = (payload.event_type or "page_view").strip().lower()[:50]

    previous_page = current_user.last_page
    current_user.last_active_at = now

    if module:
        current_user.last_module = module
    if page:
        current_user.last_page = page

    # Heartbeats keep Last Active fresh without filling the activity table.
    # A page_view is stored only when the user actually changes page.
    should_log_event = event_type != "heartbeat"
    if event_type == "page_view" and page == previous_page:
        should_log_event = False

    if should_log_event:
        db.add(
            models.UserActivity(
                user_id=current_user.id,
                company_id=current_user.company_id,
                event_type=event_type,
                module=module,
                page=page,
                created_at=now,
            )
        )

    db.commit()

    return {
        "ok": True,
        "last_active_at": now,
    }


@router.get(
    "/me",
    response_model=CurrentUserResponse,
)
def get_me(
    current_user: models.AppUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    company = None

    if current_user.company_id is not None:
        company = (
            db.query(models.Company)
            .filter(models.Company.id == current_user.company_id)
            .first()
        )

    farm_ids = [
        row.farm_id
        for row in (
            db.query(models.UserFarmAccess)
            .filter(
                models.UserFarmAccess.user_id == current_user.id,
            )
            .order_by(models.UserFarmAccess.farm_id.asc())
            .all()
        )
    ]

    return CurrentUserResponse(
        id=current_user.id,
        company_id=current_user.company_id,
        company_name=company.company_name if company else None,
        full_name=current_user.full_name,
        email=current_user.email,
        is_global_admin=current_user.is_global_admin,
        is_company_admin=current_user.is_company_admin,
        active=current_user.active,
        must_change_password=current_user.must_change_password,
        enable_broilers=company.enable_broilers if company else False,
        enable_breeders=company.enable_breeders if company else False,
        enable_layers=company.enable_layers if company else False,
        enable_hatchery=company.enable_hatchery if company else False,
        enable_processing=company.enable_processing if company else False,
        farm_ids=farm_ids,
    )

@router.post("/change-password")
def change_password(
    payload: ChangePasswordRequest,
    current_user: models.AppUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not current_user.password_hash:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="This account does not have an existing password.",
        )

    if not verify_password(
        payload.current_password,
        current_user.password_hash,
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect.",
        )

    if payload.current_password == payload.new_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="New password must be different from the current password.",
        )

    try:
        current_user.password_hash = hash_password(
            payload.new_password
        )
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(error),
        )

    current_user.must_change_password = False
    current_user.password_changed_at = datetime.utcnow()

    db.commit()

    return {
        "message": "Password changed successfully",
        "must_change_password": False,
    }

@router.post("/logout")
def logout():
    response = JSONResponse(
        content={"message": "Logged out successfully"},
        status_code=200,
    )

    response.delete_cookie(
        key=COOKIE_NAME,
        path="/",
        secure=COOKIE_SECURE,
        httponly=True,
        samesite=COOKIE_SAMESITE,
    )

    return response